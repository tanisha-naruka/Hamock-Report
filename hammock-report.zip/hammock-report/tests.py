import unittest
from hammock_report import parse, group, verdict, heuristic

ANDROID = "12/10/2026, 08:01 - Riya: hello\n12/10/2026, 08:02 - Kabir: line one\nline two\n12/10/2026, 08:03 - Riya added Meera\n12/10/2026, 08:04 - Meera: <Media omitted>"
IOS = "[12/10/26, 8:05:09 PM] Aman: evening\n[12/10/26, 12:10:00 AM] Aman: midnight"

class T(unittest.TestCase):
    def test_android_multiline_and_system(self):
        m = parse(ANDROID); self.assertEqual(len(m), 2); self.assertEqual(m[1]["text"], "line one\nline two")
    def test_ios_times(self):
        m = parse(IOS); self.assertEqual((m[0]["ts"].hour, m[1]["ts"].hour, m[0]["ts"].year), (20, 0, 2026))
    def test_grouping_gap(self):
        m = parse("12/10/2026, 08:00 - A: x\n12/10/2026, 08:10 - B: y\n12/10/2026, 09:30 - A: z")
        self.assertEqual([len(t) for t in group(m, 30)], [2, 1])
    def test_verdict_string_booleans(self):
        self.assertEqual(verdict({"needs_me": "false", "request_raised": "true", "resolved": "true"}), "resolved")
        self.assertEqual(verdict({"needs_me": "true"}), "needs")
        self.assertEqual(verdict({}), "ignore")
    def test_dry_run_flags_direct_ask(self):
        th = parse("12/10/2026, 08:00 - A: Aman, can you approve?")
        self.assertTrue(heuristic(th, "Aman")["needs_me"])

if __name__ == "__main__": unittest.main()
