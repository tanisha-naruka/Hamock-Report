# Hammock Report: DEV post draft

Fill in the bracketed parts before posting.

## What I built
Hammock Report turns a week of unread WhatsApp group chat into three piles: **Needs you**, **Already resolved** and **Safe to ignore**. Every verdict has a one-line reason, so you can check the model instead of trusting it. It ships as a single-file web app and a Python command-line script.

## Demo
- Live demo (runs with no model, using a built-in demo chat): [link]
- Screenshots: [add 3: Home, Scan, Report]
- Code: [GitHub repo link]

## How I used an open model
- Runtime: Ollama on the user's own machine. Model: Qwen2.5 3B (swap for Llama 3.2 3B with one setting).
- The chat is split into short conversations at quiet gaps (30 minutes by default), so a small model reads one conversation at a time.
- JSON mode and temperature 0 give a fixed reply format and repeatable answers.
- Safety net: if a model call fails, the conversation is filed under Needs you, so a failure never hides something.
- Very long conversations are trimmed to their start and end so they fit a small model.

## Why local
Group chats are private. Nothing is uploaded, it works offline once the model is pulled, and a bigger backlog costs time, not money.

## Honest limits
A 3B model can miss a request buried in a long thread. The dry-run mode is only a keyword check for testing. Reading-time savings assume about 5 seconds per message.

## Run it
See README.md. Tests: `python3 tests.py`.
