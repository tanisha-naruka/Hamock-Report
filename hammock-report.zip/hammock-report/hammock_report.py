#!/usr/bin/env python3
"""Hammock Report CLI: triage a WhatsApp export with a local Ollama model.
Usage: python3 hammock_report.py chat.txt --me Aman [--model qwen2.5:3b] [--gap 30] [--dry] [-o briefing.md]"""
import argparse, json, re, sys, urllib.request
from datetime import datetime

LINE = re.compile(r"^\[?(\d{1,2})/(\d{1,2})/(\d{2,4}),?\s+(\d{1,2}):(\d{2})(?::\d{2})?(?:\s?([APap][Mm]))?\]?\s*[-–]?\s*([^:]+?):\s(.*)$")
SYS = re.compile(r"^\[?\d{1,2}/\d{1,2}/\d{2,4},?\s+\d{1,2}:\d{2}")
OMIT = re.compile(r"<Media omitted>|\b(image|video|audio|sticker|GIF|document) omitted\b|This message was deleted", re.I)
PROMPT = """You triage a group chat for {me}, who was away. Read this conversation.
Reply with JSON only, with keys:
"request_raised": true/false (was a question, request or decision raised?)
"resolved": true/false (was it answered or settled later in this same conversation?)
"needs_me": true/false (does it still need {me} to act or decide, or was {me} directly asked?)
"summary": one short sentence
"reason": one short sentence explaining the verdict

Conversation:
{convo}"""
NAME = {"needs": "Needs you", "resolved": "Already resolved", "ignore": "Safe to ignore"}

def parse(text):
    msgs = []
    for raw in text.splitlines():
        raw = re.sub("[\u200e\u202f]", " ", raw).rstrip()
        m = LINE.match(raw)
        if m:
            d, mo, y, h, mi, ap, who, body = m.groups()
            y, h = int(y), int(h); y += 2000 if y < 100 else 0
            if ap and ap.lower() == "pm" and h < 12: h += 12
            if ap and ap.lower() == "am" and h == 12: h = 0
            msgs.append({"ts": datetime(y, int(mo), int(d), h, int(mi)), "who": who.strip(), "text": body})
        elif SYS.match(raw):
            continue
        elif msgs:
            msgs[-1]["text"] += "\n" + raw
    return [m for m in msgs if not OMIT.search(m["text"])]

def group(msgs, gap):
    out, cur = [], []
    for m in msgs:
        if cur and (m["ts"] - cur[-1]["ts"]).total_seconds() > gap * 60:
            out.append(cur); cur = []
        cur.append(m)
    return out + [cur] if cur else out

def render(th): return "\n".join(f"[{m['ts']:%H:%M}] {m['who']}: {m['text']}" for m in th)

def clip(s): return s if len(s) <= 6000 else s[:3000] + "\n…\n" + s[-3000:]

def heuristic(th, me):
    t = " ".join(m["text"] for m in th); mine = me.lower() in t.lower(); asked = "?" in t or mine
    return {"request_raised": asked, "resolved": len(th) > 3 and asked, "needs_me": mine and len(th) <= 3,
            "summary": th[0]["text"][:90], "reason": "Dry run: keyword check only"}

def ask(model, prompt, host):
    body = json.dumps({"model": model, "stream": False, "format": "json", "options": {"temperature": 0},
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request(host + "/api/chat", body, {"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=300) as r:
        return json.loads(json.load(r)["message"]["content"])

def yes(x): return x is True or str(x).lower() == "true"

def verdict(v): return "needs" if yes(v.get("needs_me")) else "resolved" if yes(v.get("request_raised")) and yes(v.get("resolved")) else "ignore"

def main():
    a = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    a.add_argument("chat"); a.add_argument("--me", required=True); a.add_argument("--model", default="qwen2.5:3b")
    a.add_argument("--gap", type=int, default=30); a.add_argument("--dry", action="store_true")
    a.add_argument("--host", default="http://localhost:11434"); a.add_argument("-o", "--out", default="briefing.md")
    o = a.parse_args()
    msgs = parse(open(o.chat, encoding="utf-8").read())
    if not msgs: sys.exit("No messages found. Export the chat without media.")
    if not any(m["who"].lower() == o.me.lower() for m in msgs):
        sys.exit(f"'{o.me}' is not a sender. Names found: {', '.join(sorted({m['who'] for m in msgs}))}")
    threads, items, failed = group(msgs, o.gap), [], 0
    for i, th in enumerate(threads, 1):
        print(f"\rReading {i}/{len(threads)}", end="", file=sys.stderr)
        try: v = heuristic(th, o.me) if o.dry else ask(o.model, PROMPT.format(me=o.me, convo=clip(render(th))), o.host)
        except Exception as e: failed += 1; failed == 1 and print(f"\nModel call failed ({e}). Is Ollama running and the model pulled?", file=sys.stderr); v = {"needs_me": True, "summary": th[0]["text"][:90], "reason": "Model call failed, so check this one yourself."}
        items.append((th, v, verdict(v)))
    c = {k: sum(1 for x in items if x[2] == k) for k in NAME}
    md = f"# Hammock Report for {o.me}\n\n**{len(msgs)} messages** in {len(threads)} conversations. **{c['needs']} need you.** Model: `{'dry run' if o.dry else o.model}`, failures: {failed}.\n"
    for k in NAME:
        md += f"\n## {NAME[k]} ({c[k]})\n\n"
        for th, v, kk in items:
            if kk == k: md += f"- **{th[0]['ts']:%d %b %H:%M}**: {v.get('summary', '')}\n  - _Why:_ {v.get('reason', '')}\n"
    open(o.out, "w", encoding="utf-8").write(md)
    print(f"\nWrote {o.out}: {c['needs']} need you, {c['resolved']} resolved, {c['ignore']} safe to ignore.", file=sys.stderr)

if __name__ == "__main__": main()
