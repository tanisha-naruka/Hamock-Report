# Hammock Report

Read 11 messages, not 1,400. Sorts a WhatsApp group-chat export into **Needs you**, **Already resolved** and **Safe to ignore** using a small open model on your own machine. Nothing is uploaded.

## Files
- `index.html` : the web app (single file, no build step)
- `hammock_report.py` : the same pipeline as a command-line script (Python 3, standard library only)
- `sample-chat.txt` : a tiny export to try both with (name: `Aman`)

## Web app
1. Open `index.html` in a browser. **Try the demo** works straight away with no model.
2. For real runs, install [Ollama](https://ollama.com), then:
   ```
   ollama pull qwen2.5:3b
   OLLAMA_ORIGINS="*" ollama serve
   ```
   (Windows: set `OLLAMA_ORIGINS` to `*` as an environment variable and restart Ollama.)
3. Open the **Start** screen, press **Check Ollama**, choose your export, type your name exactly as it appears in the chat, and press **Start reading**.

## Command line
```
python3 hammock_report.py sample-chat.txt --me Aman --dry     # keyword check, no model
python3 hammock_report.py chat.txt --me Aman --model qwen2.5:3b
```
Writes `briefing.md`. Options: `--gap 30` (minutes of silence between conversations), `--host`, `-o`.

## Notes
- Export in WhatsApp with **Export chat > Without media**. Android and iPhone formats both parse.
- If a model call fails, that conversation is filed under Needs you, so a failure never hides anything.
- Dry run is a keyword check for testing. Do not judge accuracy from it.
- Reading-time savings assume about 5 seconds per message.

## Tests
`python3 tests.py` checks the parser (Android and iPhone formats, multi-line messages, system lines), conversation grouping and verdict handling.

## Project layout
`index.html`, `hammock_report.py`, `tests.py`, `sample-chat.txt`, `SUBMISSION.md` (DEV post draft), `LICENSE` (MIT).

## Open in VS Code
Open this folder in VS Code (File > Open Folder). Accept the extension suggestions, right-click `index.html` and choose **Open with Live Server** (or just double-click the file). Press Ctrl/Cmd+Shift+P, then **Tasks: Run Task** to run the tests, a dry run, or Ollama.
